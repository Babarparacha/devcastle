# ==========================================
# STEP 1: THE BASE CLASS (Day 6: File Handling & Scope)
# ==========================================
class PropertyDataset:
    def __init__(self, filename):
        self.filename = filename
        
        # PROTECTED VARIABLE (_var): Subclasses can see this, but outside code shouldn't.
        self._raw_data = [] 
        self.load_data()

    def load_data(self):
        # DAY 6: Exception Handling (try-except-finally)
        try:
            file = open(self.filename, "r")
            self._raw_data = file.readlines()
            
        except FileNotFoundError:
            print(f"CRITICAL ERROR: Could not find {self.filename}")
            
        finally:
            # Always close your files to prevent memory leaks in your environment!
            if 'file' in locals() and not file.closed:
                file.close()


# ==========================================
# STEP 2: INHERITANCE (Day 5 & 6: Loops, Control Flow, Exceptions)
# ==========================================
# This class INHERITS from PropertyDataset (It automatically gets load_data)
class CleanPropertyData(PropertyDataset):
    def __init__(self, filename):
        super().__init__(filename) # This calls the Parent's __init__ method
        
        # PRIVATE VARIABLE (__var): The Locked Safe! No one can accidentally delete this.
        self.__clean_data = []     

    def process_data(self):
        print("--- Starting Data Cleaning Loop ---")
        
        # DAY 5: Enumerate() gives us both the line number (index) and the text (item)
        for index, item in enumerate(self._raw_data):
            clean_item = item.strip()
            
            # DAY 5: Conditional & Continue (Skip blank lines instantly)
            if clean_item == "":
                continue 
            
            # DAY 6: Exception Handling (Catching the "N/A" text)
            try:
                price = int(clean_item)
                
                # Nested Conditional: Only keep positive numbers
                if price > 0:
                    self.__clean_data.append(price)
                else:
                    # Using the enumerate index to print exactly WHERE the bad data was!
                    print(f"  -> Debug: Negative number found on line {index}: {price}")
                    
            except ValueError:
                # DAY 5: Pass (If it says "N/A", just do nothing and move on)
                pass 
                
        print(f"Cleaning finished! Valid rows remaining: {len(self.__clean_data)}")

    # PUBLIC METHOD: The only secure way to access the private clean_data from the outside
    def get_clean_data(self):
        return self.__clean_data


# ==========================================
# STEP 3: COMPOSITION (Day 5 & 6: Lambda, Filter, Comprehensions)
# ==========================================
class Analyzer:
    def __init__(self, data_object):
        # COMPOSITION: The analyzer takes the clean data from the object passed into it
        self.dataset = data_object.get_clean_data()

    def analyze_and_prepare(self):
        if not self.dataset:
            return "No data to analyze!"

        # REAL MATH: Calculating the Mean (Average)
        total_listings = len(self.dataset)
        average_price = sum(self.dataset) / total_listings
        
        # DAY 6: Lambda & Filter (Find all "Premium" houses strictly above average)
        premium_houses = list(filter(lambda x: x > average_price, self.dataset))
        
        # DAY 5: List Comprehension (Scale prices down by dividing by 1000 so Neural Networks train faster)
        scaled_data = [price / 1000 for price in self.dataset]

        # THE FINAL OUTPUT 
        print("\n======================================")
        print(" DATA PRE-PROCESSING ")
        print("======================================")
        print(f"Total Valid Properties: {total_listings}")
        print(f"Mean (Average) Price:   Rs. {average_price:,.2f}")
        print(f"Premium Houses Found:   {len(premium_houses)} (Using Lambda/Filter)")
        print(f"Scaled Data Sample:     {scaled_data[:3]}... (Using List Comprehension)")
        print("======================================")
        print("Status: Data is ready to feed into the Neural Network!")
        print(scaled_data)


# ==========================================
# EXECUTION: RUNNING THE PIPELINE
# ==========================================

# Initialize the Child Class (which calls the Parent Class automatically)
property_data = CleanPropertyData("price_data.txt")
property_data.process_data()

# Pass the cleaned data object into our Analyzer class
analyzer = Analyzer(property_data)
analyzer.analyze_and_prepare()