class Doctor:
    def heal(self, patient):
        print("Doctor is treating", patient.name)

class Patient:
    def __init__(self, name):
        self.name = name

p1 = Patient("Ali")
d1 = Doctor()

d1.heal(p1)









# Association (Loose Relationship)
# Two independent objects interact.
# They can live without each other.
# Doctor exists without Patient.
# Patient exists without Doctor.
# They just work together temporarily.
# ✔ Loose coupling
# ✔ Independent objects