class Book:
    def __init__(self, pages):
        self.pages = pages

class Library:
    def __init__(self, books_list):
        self.books = books_list

    def total_pages(self):
        total = 0
        for book in self.books:
            total += book.pages
        return total


b1 = Book(100)
b2 = Book(200)

lib = Library([b1, b2])

print("Total pages:", lib.total_pages())

# Aggregation (Whole–Part, but Independent Life)
# Objects are connected, but parts can exist separately.
# Books were created outside.
# Library only “contains” them.
# If library is deleted, books still exist.
# ✔ Has-a relationship
# ✔ But not strong ownership