# Variables are floating around loose
dog_name = "Max"
dog_color = "Brown"

# The function needs the data passed to it every time
def bark(name):
    print(name, "says Woof!")

bark(dog_name)

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
class Dog:
    def __init__(self, name, color):
        self.name = name  # The object remembers its own name
        self.color = color

    def bark(self):
        # We don't need to pass the name; it already knows it!
        print(self.name, "says Woof!")


# Create the object once, and it handles itself
my_dog = Dog("Max", "Brown")
my_dog.bark()


