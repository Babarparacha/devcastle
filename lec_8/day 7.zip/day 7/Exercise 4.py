class BankAccount:
    def __init__(self, name, balance):
        self.public_name = name              # Public
        self._account_type = "Savings"      # Protected
        self.__balance = balance            # Private

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print("Deposited:", amount)
        else:
            print("Invalid deposit amount")

    def withdraw(self, amount):
        if amount <= self.__balance:
            self.__balance -= amount
            print("Withdrawn:", amount)
        else:
            print("Insufficient balance")

    def show_balance(self):
        print("Current Balance:", self.__balance)


account = BankAccount("Ali", 5000)

print(account.public_name)      # Public → Works
print(account.__balance)      

account.deposit(2000)
account.withdraw(1000)


