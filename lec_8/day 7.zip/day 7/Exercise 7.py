
class Engine:
    def __init__(self, horsepower):
        self.horsepower = horsepower

    def start(self):
        print("Engine with", self.horsepower, "HP started!")

class Car:
    def __init__(self, horsepower):
        # Engine created INSIDE Car
        self.engine = Engine(horsepower)

    def start_car(self):
        self.engine.start()


car1 = Car(150)
car1.start_car()


# Composition (Strong Ownership)
# One object completely owns another.
# If parent dies → child dies.
# Engine is created inside Car.
# Engine belongs to Car.
# If Car object is deleted → Engine object is gone too.
# ✔ Strong ownership
# ✔ Composition = Part cannot exist independently