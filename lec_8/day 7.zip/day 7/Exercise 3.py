# Base class
class Calculator:
    def add(self, a, b):
        return a + b

# Child class inherits from Calculator
class AdvancedCalculator(Calculator):
    def multiply(self, a, b):
        return a * b

calc = AdvancedCalculator()

print(calc.add(5, 3))       # 8  (Inherited)
print(calc.multiply(5, 3))  # 15 (Own method)





class Add:
    def calculate(self, a, b):
        return a + b

class Multiply:
    def calculate(self, a, b):
        return a * b

# Order matters here
class MathOperation(Multiply,Add):
    pass

obj = MathOperation()
print(obj.calculate(4, 5))

print(MathOperation.__mro__)

