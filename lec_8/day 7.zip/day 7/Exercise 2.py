class Dog:
    # Class Variable: Shared by ALL dogs
    species = "Canine"
    legs = 4

    # Constructor: The "Birth" setup
    def __init__(self, name):
        # Instance Variable: Unique to THIS dog
        self.name = name
        print(self.name, "has been generated!")

    # Destructor: The "Cleanup" phase
    def __del__(self):
        print(self.name, "has been removed from memory.")

dog1 = Dog("Max")
print("Species:", dog1.species) # Accessing the shared class variable



